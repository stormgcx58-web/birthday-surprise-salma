// Central configuration file — edit this to customize the website
export const config = {
  // Personal details
  recipientName: 'Salma',
  senderName: 'Your Love',

  // Birthday message lines (each entry = one line in typewriter)
  birthdayMessage: [
    'Happy Birthday ❤️',
    '',
    'Today is your special day.',
    '',
    'I hope this year brings you endless happiness.',
    '',
    'Thank you for every smile,',
    'every memory,',
    'and every beautiful moment.',
    '',
    'You are the most amazing person I know.',
    '',
    'May all your dreams come true.',
    '',
    'Happy Birthday Salma ❤️',
  ],

  // Photos — replace with real URLs or local imports
  photos: [
    'https://images.unsplash.com/photo-1518895949257-7621c3c786d7?w=1200&q=80',
    'https://images.unsplash.com/photo-1522673607200-164d1b6ce486?w=1200&q=80',
    'https://images.unsplash.com/photo-1519741497674-611481863552?w=1200&q=80',
    'https://images.unsplash.com/photo-1529516548873-9ce57c8f155e?w=1200&q=80',
    'https://images.unsplash.com/photo-1516589178581-6cd7833ae3b2?w=1200&q=80',
  ],

  // Music — replace with your own audio URL
  musicUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
  musicTitle: 'Our Song',
  musicArtist: 'With Love',

  // Colors (CSS values)
  colors: {
    primary: '#ff69b4',     // hot pink
    secondary: '#da70d6',   // orchid purple
    accent: '#ffd700',      // gold
    bg: '#0a0010',          // deep dark bg
    bgGlow: '#1a0025',      // glow bg
  },

  // Number of candles on the cake
  candleCount: 22,

  // Gallery auto-advance interval in ms
  galleryInterval: 4000,
};
