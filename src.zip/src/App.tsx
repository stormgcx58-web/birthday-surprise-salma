import { useState, useRef, useEffect } from 'react';
import { ThemeProvider } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import { AnimatePresence } from 'framer-motion';
import theme from './theme';
import { config } from './config';
import './index.css';

import FloatingParticles from './components/FloatingParticles';
import MusicPlayer from './components/MusicPlayer';
import LoadingScene from './components/LoadingScene';
import IntroScene from './components/IntroScene';
import MessageScene from './components/MessageScene';
import GalleryScene from './components/GalleryScene';
import CakeScene from './components/CakeScene';
import FinalScene from './components/FinalScene';

type Scene = 'loading' | 'intro' | 'message' | 'gallery' | 'cake' | 'final';

export default function App() {
  // Dev shortcut: ?scene=cake or ?scene=final skips ahead
  const initialScene = (): Scene => {
    const param = new URLSearchParams(window.location.search).get('scene');
    if (param === 'cake') return 'cake';
    if (param === 'final') return 'final';
    if (param === 'gallery') return 'gallery';
    if (param === 'message') return 'message';
    return 'loading';
  };

  const [scene, setScene] = useState<Scene>(initialScene);
  const [beating, setBeating] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [musicStarted, setMusicStarted] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Initialize audio
  useEffect(() => {
    const audio = new Audio(config.musicUrl);
    audio.loop = true;
    audio.volume = 0.6;
    audioRef.current = audio;
    return () => {
      audio.pause();
      audio.src = '';
    };
  }, []);

  // Loading → Intro after 2s (only when starting at loading)
  useEffect(() => {
    if (scene !== 'loading') return;
    const timer = setTimeout(() => setScene('intro'), 2000);
    return () => clearTimeout(timer);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const startMusic = async () => {
    if (!musicStarted && audioRef.current) {
      try {
        await audioRef.current.play();
        setIsPlaying(true);
        setMusicStarted(true);
      } catch {
        // autoplay blocked; user can press play manually
      }
    }
  };

  const toggleMusic = () => {
    const audio = audioRef.current;
    if (!audio) return;
    if (isPlaying) {
      audio.pause();
      setIsPlaying(false);
    } else {
      audio.play();
      setIsPlaying(true);
      setMusicStarted(true);
    }
  };

  const handleOpenGift = async () => {
    await startMusic();
    setBeating(true);
    setTimeout(() => setScene('message'), 1200);
  };

  const go = (to: Scene) => setScene(to);

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />

      {/* Persistent dark background */}
      <div
        className="fixed inset-0"
        style={{ background: 'radial-gradient(ellipse at 50% 40%, #1a0025 0%, #0a0010 100%)' }}
      />

      {/* Floating particles always present (except loading) */}
      {false && <FloatingParticles />}

      {/* Scene transitions */}
      <AnimatePresence mode="wait">
        {scene === 'loading' && (
          <LoadingScene key="loading" />
        )}
        {scene === 'intro' && (
          <IntroScene key="intro" onOpen={handleOpenGift} beating={beating} />
        )}
        {scene === 'message' && (
          <MessageScene key="message" onNext={() => go('gallery')} />
        )}
        {scene === 'gallery' && (
          <GalleryScene key="gallery" onNext={() => go('cake')} />
        )}
        {scene === 'cake' && (
          <CakeScene key="cake" onNext={() => go('final')} />
        )}
        {scene === 'final' && (
          <FinalScene key="final" />
        )}
      </AnimatePresence>

      {/* Persistent music player (shown after intro) */}
      {scene !== 'loading' && (
        <MusicPlayer audioRef={audioRef} isPlaying={isPlaying} onToggle={toggleMusic} />
      )}
    </ThemeProvider>
  );
}
